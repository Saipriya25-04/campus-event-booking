package com.saipriya.eventbooking.service;

import com.saipriya.eventbooking.dto.AuthDtos.AuthResponse;
import com.saipriya.eventbooking.dto.AuthDtos.LoginRequest;
import com.saipriya.eventbooking.dto.AuthDtos.RegisterRequest;
import com.saipriya.eventbooking.entity.Role;
import com.saipriya.eventbooking.entity.User;
import com.saipriya.eventbooking.exception.ConflictException;
import com.saipriya.eventbooking.repository.UserRepository;
import com.saipriya.eventbooking.security.AppUserDetails;
import com.saipriya.eventbooking.security.JwtService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuthService {

    private final UserRepository users;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;

    public AuthService(UserRepository users, PasswordEncoder passwordEncoder,
                       AuthenticationManager authenticationManager, JwtService jwtService) {
        this.users = users;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
    }

    /** New sign-ups are always students; admins are created by the seeder. */
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        String email = request.email().trim().toLowerCase();
        if (users.existsByEmail(email)) {
            throw new ConflictException("An account with this email already exists");
        }
        User user = users.save(new User(request.name().trim(), email,
                passwordEncoder.encode(request.password()), Role.STUDENT));
        return toResponse(user);
    }

    public AuthResponse login(LoginRequest request) {
        var auth = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(
                request.email().trim().toLowerCase(), request.password()));
        User user = ((AppUserDetails) auth.getPrincipal()).getUser();
        return toResponse(user);
    }

    private AuthResponse toResponse(User user) {
        return new AuthResponse(jwtService.generateToken(user), user.getId(),
                user.getName(), user.getRole().name());
    }
}
