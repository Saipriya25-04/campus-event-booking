export function formatDate(value) {
  return new Date(value).toLocaleString(undefined, {
    weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit',
  });
}

export default function EventCard({ event, onBook }) {
  const full = event.seatsLeft === 0;
  return (
    <article className="card event">
      <h2>{event.title}</h2>
      <p className="muted">{formatDate(event.startTime)} · {event.location}</p>
      {event.description && <p>{event.description}</p>}
      <div className="event-foot">
        <span className={full ? 'badge full' : 'badge'}>
          {full ? 'Full' : `${event.seatsLeft} of ${event.capacity} seats left`}
        </span>
        <button disabled={full} onClick={onBook}>Book</button>
      </div>
    </article>
  );
}
