import { useEffect, useState } from 'react';
import { api } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import { formatDate } from '../components/EventCard.jsx';

export default function MyBookingsPage() {
  const { auth } = useAuth();
  const [bookings, setBookings] = useState(null);
  const [error, setError] = useState('');

  const load = () =>
    api('/api/bookings/me', { token: auth.token }).then(setBookings).catch((e) => setError(e.message));

  useEffect(() => { load(); }, []);

  async function cancel(id) {
    try {
      await api(`/api/bookings/${id}/cancel`, { method: 'POST', token: auth.token });
      load();
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <>
      <h1>My bookings</h1>
      {error && <p className="error">{error}</p>}
      {!bookings ? <p className="muted">Loading…</p> : bookings.length === 0 ? (
        <p className="muted">You haven't booked any events yet.</p>
      ) : (
        <table>
          <thead><tr><th>Event</th><th>When</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {bookings.map((b) => (
              <tr key={b.id}>
                <td>{b.eventTitle}</td>
                <td>{formatDate(b.eventStartTime)}</td>
                <td><span className={b.status === 'CONFIRMED' ? 'badge' : 'badge full'}>{b.status.toLowerCase()}</span></td>
                <td>{b.status === 'CONFIRMED' && <button className="secondary" onClick={() => cancel(b.id)}>Cancel</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </>
  );
}
