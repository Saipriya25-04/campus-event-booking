import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import EventCard from '../components/EventCard.jsx';

export default function EventsPage() {
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');
  const [page, setPage] = useState(0);
  const [data, setData] = useState(null);
  const [message, setMessage] = useState(null);
  const { auth } = useAuth();
  const navigate = useNavigate();

  async function load() {
    try {
      const params = new URLSearchParams({ page, size: 9 });
      if (query) params.set('search', query);
      setData(await api(`/api/events?${params}`));
    } catch (err) {
      setMessage({ type: 'error', text: err.message });
    }
  }

  useEffect(() => { load(); }, [page, query]);

  async function book(event) {
    if (!auth) return navigate('/login');
    try {
      await api(`/api/bookings/events/${event.id}`, { method: 'POST', token: auth.token });
      setMessage({ type: 'success', text: `You're booked for ${event.title}.` });
      load();
    } catch (err) {
      setMessage({ type: 'error', text: err.message });
    }
  }

  return (
    <>
      <div className="page-head">
        <h1>Upcoming events</h1>
        <form onSubmit={(e) => { e.preventDefault(); setPage(0); setQuery(search); }} className="search">
          <input placeholder="Search by title" value={search} onChange={(e) => setSearch(e.target.value)} />
          <button>Search</button>
        </form>
      </div>

      {message && <p className={message.type}>{message.text}</p>}

      {!data ? <p className="muted">Loading…</p> : data.content.length === 0 ? (
        <p className="muted">No upcoming events found.</p>
      ) : (
        <div className="grid">
          {data.content.map((ev) => <EventCard key={ev.id} event={ev} onBook={() => book(ev)} />)}
        </div>
      )}

      {data && data.totalPages > 1 && (
        <div className="pager">
          <button disabled={data.first} onClick={() => setPage(page - 1)}>Previous</button>
          <span>Page {data.number + 1} of {data.totalPages}</span>
          <button disabled={data.last} onClick={() => setPage(page + 1)}>Next</button>
        </div>
      )}
    </>
  );
}
