package com.saipriya.eventbooking.controller;

import com.saipriya.eventbooking.dto.BookingResponse;
import com.saipriya.eventbooking.security.AppUserDetails;
import com.saipriya.eventbooking.service.BookingService;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping("/events/{eventId}")
    @ResponseStatus(HttpStatus.CREATED)
    public BookingResponse book(@PathVariable Long eventId, @AuthenticationPrincipal AppUserDetails principal) {
        return bookingService.book(eventId, principal.getUser());
    }

    @PostMapping("/{bookingId}/cancel")
    public BookingResponse cancel(@PathVariable Long bookingId, @AuthenticationPrincipal AppUserDetails principal) {
        return bookingService.cancel(bookingId, principal.getUser());
    }

    @GetMapping("/me")
    public List<BookingResponse> myBookings(@AuthenticationPrincipal AppUserDetails principal) {
        return bookingService.myBookings(principal.getUser());
    }
}
