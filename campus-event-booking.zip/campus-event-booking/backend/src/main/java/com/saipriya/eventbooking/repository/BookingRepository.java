package com.saipriya.eventbooking.repository;

import com.saipriya.eventbooking.dto.EventReportRow;
import com.saipriya.eventbooking.entity.Booking;
import com.saipriya.eventbooking.entity.BookingStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface BookingRepository extends JpaRepository<Booking, Long> {

    long countByEventIdAndStatus(Long eventId, BookingStatus status);

    Optional<Booking> findByUserIdAndEventId(Long userId, Long eventId);

    @Query("select b from Booking b join fetch b.event where b.user.id = :userId order by b.event.startTime")
    List<Booking> findAllForUser(Long userId);

    /** One row per event with its capacity and confirmed seat count, in a single query. */
    @Query("""
            select new com.saipriya.eventbooking.dto.EventReportRow(
                e.id, e.title, e.startTime, e.capacity,
                count(case when b.status = com.saipriya.eventbooking.entity.BookingStatus.CONFIRMED then 1 end))
            from Event e left join Booking b on b.event = e
            group by e.id, e.title, e.startTime, e.capacity
            order by e.startTime
            """)
    List<EventReportRow> eventReport();
}
