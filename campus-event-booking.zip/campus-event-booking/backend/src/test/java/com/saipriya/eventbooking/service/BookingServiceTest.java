package com.saipriya.eventbooking.service;

import com.saipriya.eventbooking.dto.BookingResponse;
import com.saipriya.eventbooking.entity.*;
import com.saipriya.eventbooking.exception.ConflictException;
import com.saipriya.eventbooking.exception.NotFoundException;
import com.saipriya.eventbooking.repository.BookingRepository;
import com.saipriya.eventbooking.repository.EventRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookingServiceTest {

    @Mock BookingRepository bookings;
    @Mock EventRepository events;
    @InjectMocks BookingService service;

    User student;
    Event event;

    @BeforeEach
    void setUp() {
        student = new User("Priya", "priya@aum.edu", "hash", Role.STUDENT);
        student.setId(1L);
        User admin = new User("Admin", "admin@aum.edu", "hash", Role.ADMIN);
        event = new Event("Hackathon", "24h hackathon", "Library Hall",
                LocalDateTime.now().plusDays(3), 2, admin);
        event.setId(10L);
    }

    @Test
    void booksSeatWhenCapacityAvailable() {
        when(events.findByIdForUpdate(10L)).thenReturn(Optional.of(event));
        when(bookings.findByUserIdAndEventId(1L, 10L)).thenReturn(Optional.empty());
        when(bookings.countByEventIdAndStatus(10L, BookingStatus.CONFIRMED)).thenReturn(1L);
        when(bookings.save(any(Booking.class))).thenAnswer(inv -> inv.getArgument(0));

        BookingResponse response = service.book(10L, student);

        assertThat(response.status()).isEqualTo("CONFIRMED");
        assertThat(response.eventTitle()).isEqualTo("Hackathon");
        verify(bookings).save(any(Booking.class));
    }

    @Test
    void rejectsBookingWhenEventIsFull() {
        when(events.findByIdForUpdate(10L)).thenReturn(Optional.of(event));
        when(bookings.findByUserIdAndEventId(1L, 10L)).thenReturn(Optional.empty());
        when(bookings.countByEventIdAndStatus(10L, BookingStatus.CONFIRMED)).thenReturn(2L);

        assertThatThrownBy(() -> service.book(10L, student))
                .isInstanceOf(ConflictException.class)
                .hasMessageContaining("full");
        verify(bookings, never()).save(any());
    }

    @Test
    void rejectsDuplicateBooking() {
        when(events.findByIdForUpdate(10L)).thenReturn(Optional.of(event));
        when(bookings.findByUserIdAndEventId(1L, 10L)).thenReturn(Optional.of(new Booking(student, event)));

        assertThatThrownBy(() -> service.book(10L, student))
                .isInstanceOf(ConflictException.class)
                .hasMessageContaining("already booked");
    }

    @Test
    void reactivatesCancelledBookingInsteadOfCreatingNewRow() {
        Booking cancelled = new Booking(student, event);
        cancelled.cancel();
        when(events.findByIdForUpdate(10L)).thenReturn(Optional.of(event));
        when(bookings.findByUserIdAndEventId(1L, 10L)).thenReturn(Optional.of(cancelled));
        when(bookings.countByEventIdAndStatus(10L, BookingStatus.CONFIRMED)).thenReturn(0L);

        BookingResponse response = service.book(10L, student);

        assertThat(response.status()).isEqualTo("CONFIRMED");
        verify(bookings, never()).save(any());
    }

    @Test
    void cannotCancelSomeoneElsesBooking() {
        User other = new User("Other", "other@aum.edu", "hash", Role.STUDENT);
        other.setId(2L);
        Booking booking = new Booking(other, event);
        when(bookings.findById(5L)).thenReturn(Optional.of(booking));

        assertThatThrownBy(() -> service.cancel(5L, student))
                .isInstanceOf(NotFoundException.class);
    }
}
