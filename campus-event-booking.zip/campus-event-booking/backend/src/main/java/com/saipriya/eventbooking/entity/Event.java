package com.saipriya.eventbooking.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "events", indexes = @Index(name = "idx_event_start", columnList = "startTime"))
public class Event {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(length = 2000)
    private String description;

    @Column(nullable = false)
    private String location;

    @Column(nullable = false)
    private LocalDateTime startTime;

    @Column(nullable = false)
    private int capacity;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "created_by")
    private User createdBy;

    protected Event() {
    }

    public Event(String title, String description, String location,
                 LocalDateTime startTime, int capacity, User createdBy) {
        this.title = title;
        this.description = description;
        this.location = location;
        this.startTime = startTime;
        this.capacity = capacity;
        this.createdBy = createdBy;
    }

    public void update(String title, String description, String location,
                       LocalDateTime startTime, int capacity) {
        this.title = title;
        this.description = description;
        this.location = location;
        this.startTime = startTime;
        this.capacity = capacity;
    }

    public Long getId() { return id; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getLocation() { return location; }
    public LocalDateTime getStartTime() { return startTime; }
    public int getCapacity() { return capacity; }
    public User getCreatedBy() { return createdBy; }

    public void setId(Long id) { this.id = id; }
}
