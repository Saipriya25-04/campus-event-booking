package com.saipriya.eventbooking.entity;

public enum BookingStatus {
    CONFIRMED,
    CANCELLED
}
