package com.saipriya.eventbooking.service;

import com.saipriya.eventbooking.dto.BookingResponse;
import com.saipriya.eventbooking.entity.Booking;
import com.saipriya.eventbooking.entity.BookingStatus;
import com.saipriya.eventbooking.entity.Event;
import com.saipriya.eventbooking.entity.User;
import com.saipriya.eventbooking.exception.ConflictException;
import com.saipriya.eventbooking.exception.NotFoundException;
import com.saipriya.eventbooking.repository.BookingRepository;
import com.saipriya.eventbooking.repository.EventRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class BookingService {

    private final BookingRepository bookings;
    private final EventRepository events;

    public BookingService(BookingRepository bookings, EventRepository events) {
        this.bookings = bookings;
        this.events = events;
    }

    /**
     * Books a seat. The event row is locked for the transaction so the capacity
     * check and the insert can't race with another booking for the same event.
     */
    @Transactional
    public BookingResponse book(Long eventId, User user) {
        Event event = events.findByIdForUpdate(eventId)
                .orElseThrow(() -> new NotFoundException("Event " + eventId + " not found"));

        if (event.getStartTime().isBefore(LocalDateTime.now())) {
            throw new ConflictException("This event has already started");
        }

        Optional<Booking> existing = bookings.findByUserIdAndEventId(user.getId(), eventId);
        if (existing.isPresent() && existing.get().getStatus() == BookingStatus.CONFIRMED) {
            throw new ConflictException("You have already booked this event");
        }

        long booked = bookings.countByEventIdAndStatus(eventId, BookingStatus.CONFIRMED);
        if (booked >= event.getCapacity()) {
            throw new ConflictException("This event is full");
        }

        Booking booking;
        if (existing.isPresent()) {
            booking = existing.get();      // re-booking after a cancellation
            booking.reactivate();
        } else {
            booking = bookings.save(new Booking(user, event));
        }
        return toResponse(booking);
    }

    @Transactional
    public BookingResponse cancel(Long bookingId, User user) {
        Booking booking = bookings.findById(bookingId)
                .filter(b -> b.getUser().getId().equals(user.getId()))
                .orElseThrow(() -> new NotFoundException("Booking " + bookingId + " not found"));
        if (booking.getStatus() == BookingStatus.CANCELLED) {
            throw new ConflictException("Booking is already cancelled");
        }
        booking.cancel();
        return toResponse(booking);
    }

    @Transactional(readOnly = true)
    public List<BookingResponse> myBookings(User user) {
        return bookings.findAllForUser(user.getId()).stream().map(this::toResponse).toList();
    }

    private BookingResponse toResponse(Booking b) {
        Event e = b.getEvent();
        return new BookingResponse(b.getId(), e.getId(), e.getTitle(), e.getStartTime(),
                b.getBookedAt(), b.getStatus().name());
    }
}
