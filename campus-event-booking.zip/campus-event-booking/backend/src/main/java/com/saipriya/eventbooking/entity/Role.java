package com.saipriya.eventbooking.entity;

public enum Role {
    STUDENT,
    ADMIN
}
