package com.saipriya.eventbooking.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.saipriya.eventbooking.entity.Role;
import com.saipriya.eventbooking.entity.User;
import com.saipriya.eventbooking.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/** End-to-end through HTTP: register, log in, create an event as admin, book it as a student. */
@SpringBootTest
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
class BookingFlowIntegrationTest {

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;
    @Autowired UserRepository users;
    @Autowired PasswordEncoder encoder;

    @BeforeEach
    void seedAdmin() {
        users.save(new User("Admin", "admin@aum.edu", encoder.encode("admin-pass-123"), Role.ADMIN));
    }

    @Test
    void studentCanBookUntilEventIsFull() throws Exception {
        String admin = login("admin@aum.edu", "admin-pass-123");
        long eventId = createEvent(admin, 1);

        String alice = register("Alice", "alice@aum.edu");
        String bob = register("Bob", "bob@aum.edu");

        mvc.perform(post("/api/bookings/events/" + eventId).header("Authorization", "Bearer " + alice))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.status").value("CONFIRMED"));

        mvc.perform(post("/api/bookings/events/" + eventId).header("Authorization", "Bearer " + bob))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.detail").value("This event is full"));

        mvc.perform(get("/api/events/" + eventId))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.seatsLeft").value(0));

        mvc.perform(get("/api/reports/events").header("Authorization", "Bearer " + admin))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].confirmedBookings").value(1));
    }

    @Test
    void studentsCannotCreateEventsOrSeeReports() throws Exception {
        String student = register("Carol", "carol@aum.edu");

        mvc.perform(post("/api/events").header("Authorization", "Bearer " + student)
                        .contentType(MediaType.APPLICATION_JSON).content(eventJson(10)))
                .andExpect(status().isForbidden());

        mvc.perform(get("/api/reports/events").header("Authorization", "Bearer " + student))
                .andExpect(status().isForbidden());
    }

    @Test
    void bookingRequiresLogin() throws Exception {
        mvc.perform(post("/api/bookings/events/1")).andExpect(status().isUnauthorized());
    }

    @Test
    void registerValidatesInput() throws Exception {
        mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"\",\"email\":\"not-an-email\",\"password\":\"short\"}"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors.email").exists())
                .andExpect(jsonPath("$.errors.password").exists());
    }

    private String register(String name, String email) throws Exception {
        String body = json.writeValueAsString(new java.util.HashMap<>(java.util.Map.of(
                "name", name, "email", email, "password", "password-123")));
        String res = mvc.perform(post("/api/auth/register").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        return json.readTree(res).get("token").asText();
    }

    private String login(String email, String password) throws Exception {
        String body = "{\"email\":\"" + email + "\",\"password\":\"" + password + "\"}";
        String res = mvc.perform(post("/api/auth/login").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isOk())
                .andReturn().getResponse().getContentAsString();
        return json.readTree(res).get("token").asText();
    }

    private long createEvent(String token, int capacity) throws Exception {
        String res = mvc.perform(post("/api/events").header("Authorization", "Bearer " + token)
                        .contentType(MediaType.APPLICATION_JSON).content(eventJson(capacity)))
                .andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        JsonNode node = json.readTree(res);
        return node.get("id").asLong();
    }

    private String eventJson(int capacity) {
        return """
                {"title":"Career Fair","description":"Meet recruiters","location":"Taylor Center",
                 "startTime":"%s","capacity":%d}
                """.formatted(LocalDateTime.now().plusDays(7).withNano(0), capacity);
    }
}
