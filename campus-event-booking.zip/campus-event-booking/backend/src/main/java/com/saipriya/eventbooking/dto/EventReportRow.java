package com.saipriya.eventbooking.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.LocalDateTime;

/** Built directly by a JPQL constructor expression, so wrapper types match what Hibernate returns. */
public record EventReportRow(
        Long eventId,
        String title,
        LocalDateTime startTime,
        Integer capacity,
        Long confirmedBookings) {

    @JsonProperty("fillRatePercent")
    public double fillRatePercent() {
        if (capacity == null || capacity == 0 || confirmedBookings == null) {
            return 0;
        }
        return Math.round(confirmedBookings * 1000.0 / capacity) / 10.0;
    }
}
