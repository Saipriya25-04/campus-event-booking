# Campus Event Booking System

A full stack web app for campus events. Students browse upcoming events and book seats; admins create events and see a bookings report.

**Tech stack:** Java 17 · Spring Boot 3 · Spring Security (JWT) · Spring Data JPA / Hibernate · PostgreSQL · React 18 · Vite

## Features

- **Authentication:** register and log in with email and password. Passwords are hashed with BCrypt, and requests are authenticated with a JWT bearer token.
- **Role-based access:** `STUDENT` can browse, book, and cancel. `ADMIN` can also create, update, and delete events and view reports.
- **Event search and pagination:** `GET /api/events?search=fair&page=0&size=10`.
- **Safe seat booking:** the event row is locked (`PESSIMISTIC_WRITE`) while a booking is made, so two students can't take the last seat at the same time. A unique constraint on `(user_id, event_id)` stops duplicate bookings.
- **Reporting:** one aggregate JPQL query returns confirmed bookings and fill rate for every event.
- **Validation and errors:** request bodies are validated with Jakarta Validation, and errors return RFC 7807 `ProblemDetail` JSON.

## Architecture

```
React (Vite)  ──HTTP/JSON──▶  Spring Boot REST API  ──JPA──▶  PostgreSQL
                              controller → service → repository
                              JwtAuthFilter sets the logged-in user
```

| Layer | Package | What it does |
|---|---|---|
| Controller | `controller` | REST endpoints, request validation |
| Service | `service` | Business rules: capacity checks, duplicate bookings, ownership |
| Repository | `repository` | Spring Data JPA queries, row locking, report aggregation |
| Security | `security`, `config` | JWT creation and parsing, filter chain, CORS |

### Data model

- `users` (id, name, email unique, password hash, role)
- `events` (id, title, description, location, start_time, capacity, created_by → users)
- `bookings` (id, user_id → users, event_id → events, booked_at, status) with unique (user_id, event_id)

## API

| Method | Path | Access | Description |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Create a student account, returns a JWT |
| POST | `/api/auth/login` | Public | Log in, returns a JWT |
| GET | `/api/events` | Public | Upcoming events, with `search`, `page`, `size` |
| GET | `/api/events/{id}` | Public | One event with seats left |
| POST | `/api/events` | Admin | Create an event |
| PUT | `/api/events/{id}` | Admin | Update an event (capacity can't drop below seats booked) |
| DELETE | `/api/events/{id}` | Admin | Delete an event with no confirmed bookings |
| POST | `/api/bookings/events/{eventId}` | Logged in | Book a seat |
| POST | `/api/bookings/{id}/cancel` | Owner | Cancel a booking |
| GET | `/api/bookings/me` | Logged in | My bookings |
| GET | `/api/reports/events` | Admin | Booked vs. capacity per event |

## Running locally

**Requirements:** Java 17+, Maven, Node 18+, Docker (or a local PostgreSQL).

```bash
# 1. Database
docker compose up -d

# 2. Backend (http://localhost:8080). The admin env vars create the first admin account.
cd backend
ADMIN_EMAIL=admin@example.com ADMIN_PASSWORD=change-me-please mvn spring-boot:run

# 3. Frontend (http://localhost:5173)
cd ../frontend
npm install
npm run dev
```

On Windows PowerShell, set the admin variables with `$env:ADMIN_EMAIL="admin@example.com"` before `mvn spring-boot:run`.

Configuration is read from environment variables: `DB_URL`, `DB_USERNAME`, `DB_PASSWORD`, `JWT_SECRET` (Base64, 256-bit or more), `CORS_ORIGIN`, `ADMIN_EMAIL`, `ADMIN_PASSWORD`.

## Tests

```bash
cd backend
mvn test
```

- `BookingServiceTest`: unit tests with Mockito for capacity limits, duplicate bookings, re-booking after cancellation, and ownership checks.
- `BookingFlowIntegrationTest`: full HTTP flow with MockMvc and an in-memory H2 database, covering registration, login, admin-only endpoints, booking until full, and validation errors.

GitHub Actions runs the backend tests and the frontend build on every push.
