package com.saipriya.eventbooking.dto;

import java.time.LocalDateTime;

public record BookingResponse(
        Long id,
        Long eventId,
        String eventTitle,
        LocalDateTime eventStartTime,
        LocalDateTime bookedAt,
        String status) {
}
