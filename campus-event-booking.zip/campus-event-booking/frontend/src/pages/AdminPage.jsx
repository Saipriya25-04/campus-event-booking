import { useEffect, useState } from 'react';
import { api } from '../api.js';
import { useAuth } from '../AuthContext.jsx';
import { formatDate } from '../components/EventCard.jsx';

const empty = { title: '', description: '', location: '', startTime: '', capacity: 50 };

export default function AdminPage() {
  const { auth } = useAuth();
  const [form, setForm] = useState(empty);
  const [report, setReport] = useState([]);
  const [message, setMessage] = useState(null);

  const loadReport = () =>
    api('/api/reports/events', { token: auth.token }).then(setReport)
      .catch((e) => setMessage({ type: 'error', text: e.message }));

  useEffect(() => { loadReport(); }, []);

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  async function createEvent(e) {
    e.preventDefault();
    try {
      await api('/api/events', {
        method: 'POST',
        token: auth.token,
        body: { ...form, capacity: Number(form.capacity) },
      });
      setForm(empty);
      setMessage({ type: 'success', text: 'Event created.' });
      loadReport();
    } catch (err) {
      setMessage({ type: 'error', text: err.message });
    }
  }

  return (
    <>
      <h1>Admin</h1>
      {message && <p className={message.type}>{message.text}</p>}

      <section className="card">
        <h2>Create event</h2>
        <form onSubmit={createEvent} className="form-grid">
          <label>Title<input value={form.title} onChange={update('title')} required /></label>
          <label>Location<input value={form.location} onChange={update('location')} required /></label>
          <label>Starts<input type="datetime-local" value={form.startTime} onChange={update('startTime')} required /></label>
          <label>Capacity<input type="number" min="1" value={form.capacity} onChange={update('capacity')} required /></label>
          <label className="wide">Description<textarea rows="3" value={form.description} onChange={update('description')} /></label>
          <button className="wide">Create event</button>
        </form>
      </section>

      <section className="card">
        <h2>Bookings report</h2>
        {report.length === 0 ? <p className="muted">No events yet.</p> : (
          <table>
            <thead><tr><th>Event</th><th>When</th><th>Booked</th><th>Capacity</th><th>Fill rate</th></tr></thead>
            <tbody>
              {report.map((r) => (
                <tr key={r.eventId}>
                  <td>{r.title}</td>
                  <td>{formatDate(r.startTime)}</td>
                  <td>{r.confirmedBookings}</td>
                  <td>{r.capacity}</td>
                  <td>{r.fillRatePercent}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </>
  );
}
