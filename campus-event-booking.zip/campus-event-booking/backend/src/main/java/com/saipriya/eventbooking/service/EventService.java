package com.saipriya.eventbooking.service;

import com.saipriya.eventbooking.dto.EventDtos.EventRequest;
import com.saipriya.eventbooking.dto.EventDtos.EventResponse;
import com.saipriya.eventbooking.entity.BookingStatus;
import com.saipriya.eventbooking.entity.Event;
import com.saipriya.eventbooking.entity.User;
import com.saipriya.eventbooking.exception.ConflictException;
import com.saipriya.eventbooking.exception.NotFoundException;
import com.saipriya.eventbooking.repository.BookingRepository;
import com.saipriya.eventbooking.repository.EventRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class EventService {

    private final EventRepository events;
    private final BookingRepository bookings;

    public EventService(EventRepository events, BookingRepository bookings) {
        this.events = events;
        this.bookings = bookings;
    }

    @Transactional(readOnly = true)
    public Page<EventResponse> listUpcoming(String search, Pageable pageable) {
        LocalDateTime now = LocalDateTime.now();
        Page<Event> page = (search == null || search.isBlank())
                ? events.findByStartTimeAfterOrderByStartTimeAsc(now, pageable)
                : events.findByTitleContainingIgnoreCaseAndStartTimeAfterOrderByStartTimeAsc(search.trim(), now, pageable);
        return page.map(this::toResponse);
    }

    @Transactional(readOnly = true)
    public EventResponse get(Long id) {
        return toResponse(find(id));
    }

    @Transactional
    public EventResponse create(EventRequest req, User admin) {
        Event event = events.save(new Event(req.title(), req.description(), req.location(),
                req.startTime(), req.capacity(), admin));
        return toResponse(event);
    }

    @Transactional
    public EventResponse update(Long id, EventRequest req) {
        Event event = find(id);
        long booked = bookings.countByEventIdAndStatus(id, BookingStatus.CONFIRMED);
        if (req.capacity() < booked) {
            throw new ConflictException("Capacity cannot be lower than the " + booked + " seats already booked");
        }
        event.update(req.title(), req.description(), req.location(), req.startTime(), req.capacity());
        return toResponse(event);
    }

    @Transactional
    public void delete(Long id) {
        Event event = find(id);
        if (bookings.countByEventIdAndStatus(id, BookingStatus.CONFIRMED) > 0) {
            throw new ConflictException("Cannot delete an event that has confirmed bookings");
        }
        events.delete(event);
    }

    private Event find(Long id) {
        return events.findById(id).orElseThrow(() -> new NotFoundException("Event " + id + " not found"));
    }

    private EventResponse toResponse(Event e) {
        long booked = bookings.countByEventIdAndStatus(e.getId(), BookingStatus.CONFIRMED);
        return new EventResponse(e.getId(), e.getTitle(), e.getDescription(), e.getLocation(),
                e.getStartTime(), e.getCapacity(), booked, Math.max(0, e.getCapacity() - booked));
    }
}
