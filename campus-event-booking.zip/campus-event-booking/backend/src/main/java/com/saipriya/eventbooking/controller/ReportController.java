package com.saipriya.eventbooking.controller;

import com.saipriya.eventbooking.dto.EventReportRow;
import com.saipriya.eventbooking.repository.BookingRepository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Admin-only reporting: seats booked vs. capacity for every event. */
@RestController
@RequestMapping("/api/reports")
public class ReportController {

    private final BookingRepository bookings;

    public ReportController(BookingRepository bookings) {
        this.bookings = bookings;
    }

    @GetMapping("/events")
    @Transactional(readOnly = true)
    public List<EventReportRow> eventReport() {
        return bookings.eventReport();
    }
}
