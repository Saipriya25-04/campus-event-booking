import { Link, Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './AuthContext.jsx';
import EventsPage from './pages/EventsPage.jsx';
import LoginPage from './pages/LoginPage.jsx';
import MyBookingsPage from './pages/MyBookingsPage.jsx';
import AdminPage from './pages/AdminPage.jsx';

function RequireAuth({ children, admin = false }) {
  const { auth, isAdmin } = useAuth();
  if (!auth) return <Navigate to="/login" replace />;
  if (admin && !isAdmin) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  const { auth, isAdmin, signOut } = useAuth();

  return (
    <>
      <header className="topbar">
        <Link to="/" className="brand">Campus Events</Link>
        <nav>
          <Link to="/">Events</Link>
          {auth && <Link to="/bookings">My bookings</Link>}
          {isAdmin && <Link to="/admin">Admin</Link>}
          {auth ? (
            <button className="link-button" onClick={signOut}>Sign out ({auth.name})</button>
          ) : (
            <Link to="/login">Sign in</Link>
          )}
        </nav>
      </header>

      <main className="container">
        <Routes>
          <Route path="/" element={<EventsPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/bookings" element={<RequireAuth><MyBookingsPage /></RequireAuth>} />
          <Route path="/admin" element={<RequireAuth admin><AdminPage /></RequireAuth>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </>
  );
}
