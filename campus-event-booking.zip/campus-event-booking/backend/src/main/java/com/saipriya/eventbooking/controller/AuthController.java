package com.saipriya.eventbooking.controller;

import com.saipriya.eventbooking.dto.AuthDtos.AuthResponse;
import com.saipriya.eventbooking.dto.AuthDtos.LoginRequest;
import com.saipriya.eventbooking.dto.AuthDtos.RegisterRequest;
import com.saipriya.eventbooking.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public AuthResponse register(@Valid @RequestBody RegisterRequest request) {
        return authService.register(request);
    }

    @PostMapping("/login")
    public AuthResponse login(@Valid @RequestBody LoginRequest request) {
        return authService.login(request);
    }
}
