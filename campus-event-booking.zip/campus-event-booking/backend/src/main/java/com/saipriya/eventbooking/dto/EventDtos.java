package com.saipriya.eventbooking.dto;

import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDateTime;

public final class EventDtos {

    private EventDtos() {
    }

    public record EventRequest(
            @NotBlank @Size(max = 150) String title,
            @Size(max = 2000) String description,
            @NotBlank String location,
            @NotNull @Future LocalDateTime startTime,
            @Min(1) @Max(10000) int capacity) {
    }

    public record EventResponse(
            Long id,
            String title,
            String description,
            String location,
            LocalDateTime startTime,
            int capacity,
            long seatsBooked,
            long seatsLeft) {
    }
}
