package com.saipriya.eventbooking.config;

import com.saipriya.eventbooking.entity.Role;
import com.saipriya.eventbooking.entity.User;
import com.saipriya.eventbooking.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/** Creates the first admin account from ADMIN_EMAIL / ADMIN_PASSWORD if they are set. */
@Component
public class AdminSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(AdminSeeder.class);

    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final String email;
    private final String password;

    public AdminSeeder(UserRepository users, PasswordEncoder encoder,
                       @Value("${ADMIN_EMAIL:}") String email,
                       @Value("${ADMIN_PASSWORD:}") String password) {
        this.users = users;
        this.encoder = encoder;
        this.email = email.trim().toLowerCase();
        this.password = password;
    }

    @Override
    public void run(String... args) {
        if (email.isEmpty() || password.isEmpty() || users.existsByEmail(email)) {
            return;
        }
        users.save(new User("Admin", email, encoder.encode(password), Role.ADMIN));
        log.info("Created admin account {}", email);
    }
}
