package com.saipriya.eventbooking.repository;

import com.saipriya.eventbooking.entity.Event;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import jakarta.persistence.LockModeType;
import java.time.LocalDateTime;
import java.util.Optional;

public interface EventRepository extends JpaRepository<Event, Long> {

    Page<Event> findByStartTimeAfterOrderByStartTimeAsc(LocalDateTime after, Pageable pageable);

    Page<Event> findByTitleContainingIgnoreCaseAndStartTimeAfterOrderByStartTimeAsc(
            String title, LocalDateTime after, Pageable pageable);

    /** Locks the event row so two students can't take the last seat at the same time. */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select e from Event e where e.id = :id")
    Optional<Event> findByIdForUpdate(@Param("id") Long id);
}
