// Small fetch wrapper: adds the JWT, parses JSON, and turns API errors into readable messages.
const BASE = import.meta.env.VITE_API_URL ?? '';

export async function api(path, { method = 'GET', body, token } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${BASE}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  if (res.status === 204) return null;
  const data = await res.json().catch(() => null);

  if (!res.ok) {
    const fieldErrors = data?.errors ? Object.entries(data.errors).map(([f, m]) => `${f} ${m}`).join(', ') : '';
    const message = fieldErrors || data?.detail || (res.status === 403 ? 'Not allowed' : `Request failed (${res.status})`);
    throw new Error(message);
  }
  return data;
}
